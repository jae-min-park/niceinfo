package com.niceinfo.eais.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
public class InernalServerErrorException extends RuntimeException {
	private static final long serialVersionUID = 1L;

	public InernalServerErrorException(String msg) {
		super(msg);
	}
}
