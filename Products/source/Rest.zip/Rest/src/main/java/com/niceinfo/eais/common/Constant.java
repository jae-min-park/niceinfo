package com.niceinfo.eais.common;

public class Constant {
	public static final String DB_SELECT_ERROR = "DB_SELECT_ERROR";
	public static final String DB_INSERT_ERROR = "DB_INSERT_ERROR";
	public static final String JSON_PARSE_ERROR = "JSON_PARSE_ERROR";
}
